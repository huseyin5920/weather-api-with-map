from pymongo import MongoClient
from constants import constants


class MongodbConnection():

    def __init__(self):
        client = MongoClient(constants.MONGO_CONNECTION_URL)
        db = client["weather"]
        try: db.command("serverStatus")
        except Exception as e: print(e)
        else: print("You are connected!")
        client.close()
        return db

    def getCollection(self, collectionName):
        if collectionName in self.collectionList:
            return self.collectionList[collectionName]
        else:
            collection = self.__db[collectionName]
            self.collectionList[collectionName] = collection
            return collection

    def saveToCollection(self, collectionName, data):
        return self.getCollection(collectionName=collectionName).insert_one(data)