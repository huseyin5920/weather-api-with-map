from typing import Collection
import requests
from constants import constants
from utils import turkeyCities
from db import mongodbConnection
from utils import turkeyCities
import threading
from db import mongodbConnection
from pymongo import MongoClient



client = MongoClient("mongodb://XXX:XXX@localhost:27017")
db = client["weather"]
my_col = db["weather_collection"]
try: db.command("serverStatus")
except Exception as e: print(e)
else: print("You are connected!")

def getWeatherDataByCity():
    print(len(turkeyCities.cities))
    for i in range(81):
        responseWeatherData = requests.get(
            constants.BASE_URL + "appid=" + constants.API_KEY + "&q=" + turkeyCities.cities[i]["name"] + "&lang=tr" + "&units=metric")
        
        weatherDataByCity = responseWeatherData.json()
        print(weatherDataByCity)
        print(type(weatherDataByCity))
        my_col.insert_one(weatherDataByCity)




def run():
    threading.Timer(9000.0, run).start() # called every minute
    getWeatherDataByCity()
    print("******HAVA DURUMU ALINDI******")
run()

