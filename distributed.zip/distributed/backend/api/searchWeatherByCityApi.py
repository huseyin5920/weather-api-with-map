from typing import Sequence
from flask_cors import cross_origin
from service.getWeatherData import GetWeatherData
from flask import request, jsonify
from db.mongodbConnection import MongodbConnection
import json
from bson import json_util

@cross_origin()
def getWeatherByCity():
    cityName = request.json["cityName"]
    result = GetWeatherData.getWeatherByCity(cityName)
    return json.loads(json_util.dumps(result))

  
@cross_origin()
def getWeatherByMain():
    main = request.json["main"]
    result = GetWeatherData.getWeatherByMain(main)
    return result
    # print(type(result))
    # result = json.dumps(result)
    # print(type(result))
    # return result
    #return json.loads(json_util.dumps(result))



