from flask import Flask
from constants import constants
from api import (
    searchWeatherByCityApi,
    findCurrentLocationApi
)
from flask import Flask, jsonify, request
from flask_restful import Api, Resource
from typing import Sequence
from flask_cors import cross_origin
from service.getWeatherData import GetWeatherData
from flask import request, jsonify
from db.mongodbConnection import MongodbConnection
import json
from bson import json_util


app = Flask(__name__)
api = Api(app)

@cross_origin()
@app.route('/weatherbycity', methods=['GET'])
def getWeatherByCity():
    cityName = request.args.get('city')   
    print(cityName)
    #cityName = request.json["cityName"]
    result = GetWeatherData.getWeatherByCity(cityName)
    return json.loads(json_util.dumps(result))

  

@cross_origin()
@app.route('/weatherbymain', methods=['GET'])
def getWeatherByMain():
    main = request.args.get("main")
    print(main)
    result = GetWeatherData.getWeatherByMain(main)
    return result

@cross_origin()
@app.route('/weatherbyfeel', methods=['GET'])
def getWeatherByFeel():
    main = request.args.get("feelTemperature")
    print(main)
    result = GetWeatherData.getWeatherByFeelTemperature(main)
    return result

@cross_origin()
@app.route('/weatherbycondition', methods=['GET'])
def getWeatherByCondition():
    main = request.args.get("condition")
    print(main)
    result = GetWeatherData.getWeatherCondition(main)
    return result


@cross_origin()
@app.route('/', methods=['GET'])
def getWeatherApis():
    return {"1": "http://localhost:5000/weatherbycondition?condition=Clouds",
            "2": "http://localhost:5000/weatherbycity?city=Ankara",
            "3": "http://localhost:5000/weatherbyfeel?feelTemperature=10",
            "4": "http://localhost:5000/weatherbymain?main=Rain",
            
    
    
    }


# app.add_url_rule(
#     "/weatherByCity", view_func=searchWeatherByCityApi.getWeatherByCity, methods=["POST"]
# )

# app.add_url_rule(
#     "/weatherByMain", view_func=searchWeatherByCityApi.getWeatherByMain, methods=["POST"]
# )


# app.add_url_rule(
#     "/findMyLocation", view_func=findCurrentLocationApi.getCurrentLocation, methods=["GET"]
# )
if __name__ == "__main__":
    app.run(constants.FLASK_HOST, constants.FLASK_PORT, debug=True)
