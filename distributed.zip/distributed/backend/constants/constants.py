API_KEY = "XXX"
BASE_URL = "http://api.openweathermap.org/data/2.5/weather?"
FLASK_HOST = "0.0.0.0"
FLASK_PORT = 5000
FIND_LOCATION_FROM_IP = "me"
MONGO_CONNECTION_URL = "mongodb://XXX:XXX@localhost:27017"
MONGO_WEATHER_COLLECTION = "weather"
dt = "Data receiving time"
