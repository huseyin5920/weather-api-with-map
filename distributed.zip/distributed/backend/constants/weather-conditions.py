weatherConditions = {
    "Thunderstorm": "Thunderstorm",
    "Drizzle": "Drizzle",
    "Rain": "Rain",
    "Snow": "Snow",
    "Clear": "Clear",
    "Clouds": "Clouds",
}
