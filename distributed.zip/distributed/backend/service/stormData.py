import requests

url = "https://stormglass.p.rapidapi.com/forecast"

querystring = {"lng": "32.8543", "lat": "39.9199"}

headers = {
    'x-rapidapi-host': "stormglass.p.rapidapi.com",
    'x-rapidapi-key': "0540ec8df0msh6475fe904f8209ap12e13bjsnb01c93a2cb34"
}

response = requests.request("GET", url, headers=headers, params=querystring)

print(response.text)
