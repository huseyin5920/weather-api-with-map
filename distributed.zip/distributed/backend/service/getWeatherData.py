# python_test.py
from typing import FrozenSet
import requests
from constants import constants
from utils import turkeyCities
from flask import jsonify
from bson.json_util import dumps, loads

from db.mongodbConnection import MongodbConnection

class GetWeatherData():

    def getWeatherByCity(cityName):
        conn = MongodbConnection.connectDB()
        cursor = conn.find({"name": cityName})
        for document in cursor:
            print(type(document))
        return document



    def getWeatherByMain(main):
        mainList = []
        conn = MongodbConnection.connectDB()
        cursor = conn.find({"weather.main": main})
        print(type(cursor))
        for document in cursor:
            print(document)
            try:
                dict = {
                    'id': document['_id'],
                    'coord-lan': document['coord']['lon'],
                    'coord-lat': document['coord']['lat'],
                    'weather-main': document['weather'][0]['main'],
                    'weather-description': document['weather'][0]['description'],
                    'weather-icon': document['weather'][0]['icon'],
                    'base': document['base'],
                    'main-temp': document['main']['temp'],
                    'main-feels_like': document['main']['feels_like'],
                    'main-pressure': document['main']['pressure'],
                    'main-humidity': document['main']['humidity'],
                    'main-temp_min': document['main']['temp_min'],
                    'main-temp_max': document['main']['temp_max'],
                    'visibility': document['visibility'],
                    'wind-speed': document['wind']['speed'],
                    'wind-deg': document['wind']['deg'],
                    'clouds-all': document['clouds']['all'],
                    'dt': document['dt'],
                    'sys-country': document['sys']['country'],
                    'sys-sunrise': document['sys']['sunrise'],
                    'sys-sunset': document['sys']['sunset'],
                    'timezone': document['timezone'],
                    'id': document['id'],
                    'name': document['name'],
                    'cod': document['cod']
                }

            except:
                print("ÜLKE BOZUK")
            mainList.append(dict)
        print(mainList)
    
        response= jsonify(mainList)
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response     

    #   for rss_collection in mynet_tasks:
    #     task_list_mynet.append({'baslik': rss_collection['baslik'], 'kisa_bilgi': rss_collection['kisa_bilgi'], 'link': rss_collection['link'], 'zaman': rss_collection['zaman'], 'saglayici': rss_collection['saglayici']})

# Converting to the JSON
        # json_data = dumps(list_cur, indent = 2) 
        # for document in cursor:
        #     mainList["name"] = document["name"]
        #     mainList.append(document)
        # return jsonify(mainList)


    def getWeatherByFeelTemperature(feelTemperature):
        mainList = []
        conn = MongodbConnection.connectDB()
        cursor = conn.find({"main.feels_like":{"$gt":int(feelTemperature)} })
        print(type(cursor))
        for document in cursor:
            print(document)
            try:
                dict = {
                    'id': document['_id'],
                    'coord-lan': document['coord']['lon'],
                    'coord-lat': document['coord']['lat'],
                    'weather-main': document['weather'][0]['main'],
                    'weather-description': document['weather'][0]['description'],
                    'weather-icon': document['weather'][0]['icon'],
                    'base': document['base'],
                    'main-temp': document['main']['temp'],
                    'main-feels_like': document['main']['feels_like'],
                    'main-pressure': document['main']['pressure'],
                    'main-humidity': document['main']['humidity'],
                    'main-temp_min': document['main']['temp_min'],
                    'main-temp_max': document['main']['temp_max'],
                    'visibility': document['visibility'],
                    'wind-speed': document['wind']['speed'],
                    'wind-deg': document['wind']['deg'],
                    'clouds-all': document['clouds']['all'],
                    'dt': document['dt'],
                    'sys-country': document['sys']['country'],
                    'sys-sunrise': document['sys']['sunrise'],
                    'sys-sunset': document['sys']['sunset'],
                    'timezone': document['timezone'],
                    'id': document['id'],
                    'name': document['name'],
                    'cod': document['cod']
                }

            except:
                print("ÜLKE BOZUK")
            mainList.append(dict)
        print(mainList)
    
        response= jsonify(mainList)
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response   


    def getWeatherCondition(conditionTemperature):
        mainList = []
        conn = MongodbConnection.connectDB()
        cursor = conn.find({"weather.main":conditionTemperature })
        print(type(cursor))
        for document in cursor:
            print(document)
            try:
                dict = {
                    'id': document['_id'],
                    'coord-lan': document['coord']['lon'],
                    'coord-lat': document['coord']['lat'],
                    'weather-main': document['weather'][0]['main'],
                    'weather-description': document['weather'][0]['description'],
                    'weather-icon': document['weather'][0]['icon'],
                    'base': document['base'],
                    'main-temp': document['main']['temp'],
                    'main-feels_like': document['main']['feels_like'],
                    'main-pressure': document['main']['pressure'],
                    'main-humidity': document['main']['humidity'],
                    'main-temp_min': document['main']['temp_min'],
                    'main-temp_max': document['main']['temp_max'],
                    'visibility': document['visibility'],
                    'wind-speed': document['wind']['speed'],
                    'wind-deg': document['wind']['deg'],
                    'clouds-all': document['clouds']['all'],
                    'dt': document['dt'],
                    'sys-country': document['sys']['country'],
                    'sys-sunrise': document['sys']['sunrise'],
                    'sys-sunset': document['sys']['sunset'],
                    'timezone': document['timezone'],
                    'id': document['id'],
                    'name': document['name'],
                    'cod': document['cod']
                }

            except:
                print("ÜLKE BOZUK")
            mainList.append(dict)
        print(mainList)
    
        response= jsonify(mainList)
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response   