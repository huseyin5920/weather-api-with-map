from pymongo import MongoClient
from constants import constants


class MongodbConnection:
    def connectDB():
        client = MongoClient(constants.MONGO_CONNECTION_URL)
        db = client["weather"]
        collection = db["weather_collection"]
        return collection

    def saveToCollection(self, collectionName, data):
        return self.getCollection(collectionName=collectionName).insert_one(data).inserted_id


